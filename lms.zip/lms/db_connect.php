<?php
  $servername = "localhost";
  $username = "root";
  $password = "s3cureinf0";

	#don't reuse this password

  $dbname = "lms_db";
  $conn = new mysqli($servername,$username,$password,$dbname);
  